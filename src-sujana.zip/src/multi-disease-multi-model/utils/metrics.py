"""
Evaluation metrics for multi-disease detection
"""

import torch
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, 
    f1_score, roc_auc_score, confusion_matrix
)


def compute_metrics(predictions, targets):
    """
    Compute comprehensive metrics for all diseases.
    
    Args:
        predictions: Dict with disease predictions [batch, num_classes]
        targets: Dict with ground truth labels [batch]
        
    Returns:
        metrics: Dict with metrics for each disease
    """
    metrics = {}
    
    for disease in ['diabetes', 'alzheimer', 'cancer', 'cvd']:
        # Get predicted classes
        pred_classes = torch.argmax(predictions[disease], dim=1).numpy()
        true_classes = targets[disease].numpy()
        
        # Compute metrics
        disease_metrics = {
            'accuracy': accuracy_score(true_classes, pred_classes),
            'precision': precision_score(true_classes, pred_classes, average='weighted', zero_division=0),
            'recall': recall_score(true_classes, pred_classes, average='weighted', zero_division=0),
            'f1': f1_score(true_classes, pred_classes, average='weighted', zero_division=0)
        }
        
        # Confusion matrix
        cm = confusion_matrix(true_classes, pred_classes)
        disease_metrics['confusion_matrix'] = cm
        
        # AUC-ROC (if binary or multi-class with probabilities)
        try:
            pred_probs = torch.softmax(predictions[disease], dim=1).numpy()
            auc = roc_auc_score(
                true_classes, pred_probs,
                multi_class='ovr', average='weighted'
            )
            disease_metrics['auc_roc'] = auc
        except:
            disease_metrics['auc_roc'] = None
        
        metrics[disease] = disease_metrics
    
    # Average metrics across diseases
    metrics['average'] = {
        'accuracy': np.mean([m['accuracy'] for m in metrics.values() if 'accuracy' in m]),
        'precision': np.mean([m['precision'] for m in metrics.values() if 'precision' in m]),
        'recall': np.mean([m['recall'] for m in metrics.values() if 'recall' in m]),
        'f1': np.mean([m['f1'] for m in metrics.values() if 'f1' in m])
    }
    
    return metrics


def print_metrics(metrics):
    """Pretty print metrics."""
    print("\n" + "="*60)
    print("EVALUATION METRICS")
    print("="*60)
    
    for disease, disease_metrics in metrics.items():
        if disease == 'average':
            print("\n" + "-"*60)
            print(f"AVERAGE ACROSS ALL DISEASES:")
        else:
            print(f"\n{disease.upper()}:")
        
        print(f"  Accuracy:  {disease_metrics['accuracy']:.4f}")
        print(f"  Precision: {disease_metrics['precision']:.4f}")
        print(f"  Recall:    {disease_metrics['recall']:.4f}")
        print(f"  F1-Score:  {disease_metrics['f1']:.4f}")
        
        if 'auc_roc' in disease_metrics and disease_metrics['auc_roc']:
            print(f"  AUC-ROC:   {disease_metrics['auc_roc']:.4f}")
    
    print("="*60 + "\n")

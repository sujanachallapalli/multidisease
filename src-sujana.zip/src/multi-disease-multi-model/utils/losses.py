"""
Loss functions for multi-task multi-disease learning
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    """Focal Loss for handling class imbalance."""
    
    def __init__(self, alpha=0.25, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        
    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        pt = torch.exp(-ce_loss)
        focal_loss = self.alpha * (1 - pt) ** self.gamma * ce_loss
        return focal_loss.mean()


class MultiTaskLoss(nn.Module):
    """
    Multi-task loss for all disease predictions.
    
    Loss = λ_diab * L_diab + λ_alz * L_alz + λ_canc * L_canc + 
           λ_cvd * L_cvd + λ_early * L_early + λ_comorbid * L_comorbid
    """
    
    def __init__(self, weights=None, device='cuda'):
        super(MultiTaskLoss, self).__init__()
        
        # Default weights
        if weights is None:
            weights = {
                'diabetes': 1.0,
                'alzheimer': 0.8,
                'cancer': 1.2,
                'cvd': 0.9,
                'comorbidity': 0.3
            }
        self.weights = weights
        
        # Individual loss functions
        self.diabetes_loss = FocalLoss(alpha=0.25, gamma=2.0)
        self.alzheimer_loss = nn.CrossEntropyLoss()
        self.cancer_loss = FocalLoss(alpha=0.25, gamma=2.0)
        self.cvd_loss = nn.CrossEntropyLoss()
        self.comorbidity_loss = nn.MSELoss()
        
    def forward(self, predictions, targets):
        """
        Args:
            predictions: Dict with disease predictions
            targets: Dict with ground truth labels
            
        Returns:
            total_loss: Weighted sum of all losses
        """
        loss_diabetes = self.diabetes_loss(
            predictions['diabetes'], targets['diabetes']
        )
        
        loss_alzheimer = self.alzheimer_loss(
            predictions['alzheimer'], targets['alzheimer']
        )
        
        loss_cancer = self.cancer_loss(
            predictions['cancer'], targets['cancer']
        )
        
        loss_cvd = self.cvd_loss(
            predictions['cvd'], targets['cvd']
        )
        
        # Comorbidity score (if provided)
        if 'comorbidity_score' in targets:
            loss_comorbidity = self.comorbidity_loss(
                predictions['comorbidity_score'],
                targets['comorbidity_score']
            )
        else:
            loss_comorbidity = 0.0
        
        # Weighted sum
        total_loss = (
            self.weights['diabetes'] * loss_diabetes +
            self.weights['alzheimer'] * loss_alzheimer +
            self.weights['cancer'] * loss_cancer +
            self.weights['cvd'] * loss_cvd +
            self.weights['comorbidity'] * loss_comorbidity
        )
        
        return total_loss

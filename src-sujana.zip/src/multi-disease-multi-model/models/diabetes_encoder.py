"""
BioBERT Encoder for Type 2 Diabetes Detection from EHR
Processes clinical notes + structured lab features
"""

import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer


class DiabetesEncoder(nn.Module):
    """
    BioBERT-based encoder for diabetes detection from EHR data.
    
    Architecture:
    - BioBERT: Processes clinical notes (512 tokens max)
    - Structured pathway: Processes 15 lab features
    - Fusion: Concatenates text + structured embeddings
    
    Args:
        structured_dim (int): Number of structured features (default: 15)
        text_embedding_dim (int): BioBERT embedding dimension (default: 768)
        hidden_dim (int): Hidden layer dimension (default: 256)
        output_dim (int): Final embedding dimension (default: 256)
        dropout (float): Dropout probability (default: 0.3)
    """
    
    def __init__(
        self,
        structured_dim=15,
        text_embedding_dim=768,
        hidden_dim=256,
        output_dim=256,
        dropout=0.3
    ):
        super(DiabetesEncoder, self).__init__()
        
        # BioBERT for clinical text
        self.biobert = BertModel.from_pretrained('dmis-lab/biobert-v1.1')
        
        # Text projection pathway
        self.text_projection = nn.Sequential(
            nn.Linear(text_embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Structured features pathway
        self.structured_pathway = nn.Sequential(
            nn.Linear(structured_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Linear(128, hidden_dim),
            nn.ReLU()
        )
        
        # Fusion layer
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, output_dim),
            nn.ReLU()
        )
        
    def forward(self, input_ids, attention_mask, structured_features):
        """
        Forward pass through BioBERT encoder.
        
        Args:
            input_ids: Tokenized clinical notes [batch_size, 512]
            attention_mask: Attention mask for padding [batch_size, 512]
            structured_features: Lab values [batch_size, 15]
            
        Returns:
            diabetes_embedding: Patient embedding [batch_size, 256]
        """
        # Process clinical text through BioBERT
        bert_output = self.biobert(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        
        # Extract [CLS] token embedding
        cls_embedding = bert_output.last_hidden_state[:, 0, :]  # [batch, 768]
        
        # Project text embedding
        text_features = self.text_projection(cls_embedding)  # [batch, 256]
        
        # Process structured features
        struct_features = self.structured_pathway(structured_features)  # [batch, 256]
        
        # Concatenate and fuse
        combined = torch.cat([text_features, struct_features], dim=1)  # [batch, 512]
        diabetes_embedding = self.fusion(combined)  # [batch, 256]
        
        return diabetes_embedding


class DiabetesClassifier(nn.Module):
    """
    Full diabetes classification model with encoder + classifier head.
    
    Classes: Healthy (0), Pre-diabetes (1), Type 2 Diabetes (2)
    """
    
    def __init__(self, encoder, num_classes=3):
        super(DiabetesClassifier, self).__init__()
        self.encoder = encoder
        self.classifier = nn.Linear(256, num_classes)
        
    def forward(self, input_ids, attention_mask, structured_features):
        embedding = self.encoder(input_ids, attention_mask, structured_features)
        logits = self.classifier(embedding)
        return logits, embedding


def create_diabetes_encoder(pretrained=False, checkpoint_path=None):
    """
    Factory function to create diabetes encoder.
    
    Args:
        pretrained (bool): Load pretrained weights
        checkpoint_path (str): Path to checkpoint file
        
    Returns:
        model: DiabetesEncoder instance
    """
    model = DiabetesEncoder()
    
    if pretrained and checkpoint_path:
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
        model.load_state_dict(checkpoint['model_state_dict'])
        print(f"Loaded pretrained diabetes encoder from {checkpoint_path}")
        
    return model


if __name__ == "__main__":
    # Test the model
    batch_size = 4
    model = DiabetesEncoder()
    
    # Dummy inputs
    input_ids = torch.randint(0, 30522, (batch_size, 512))
    attention_mask = torch.ones(batch_size, 512)
    structured_features = torch.randn(batch_size, 15)
    
    # Forward pass
    embedding = model(input_ids, attention_mask, structured_features)
    print(f"Diabetes embedding shape: {embedding.shape}")  # [4, 256]
    
    # Test full classifier
    classifier = DiabetesClassifier(model, num_classes=3)
    logits, emb = classifier(input_ids, attention_mask, structured_features)
    print(f"Logits shape: {logits.shape}")  # [4, 3]

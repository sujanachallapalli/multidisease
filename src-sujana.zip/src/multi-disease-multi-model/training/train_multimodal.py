"""
Training script for complete Multi-Modal Multi-Disease Framework
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import argparse
import yaml
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).parent.parent))

from models.multimodal_framework import MultiModalFramework
from utils.losses import MultiTaskLoss
from utils.metrics import compute_metrics
from datasets.multimodal_dataset import MultiModalDataset


def train_epoch(model, train_loader, criterion, optimizer, device, epoch):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    
    for batch_idx, (batch, labels) in enumerate(train_loader):
        # Move to device
        batch = {k: v.to(device) for k, v in batch.items()}
        labels = {k: v.to(device) for k, v in labels.items()}
        
        # Forward pass
        optimizer.zero_grad()
        predictions = model(batch)
        
        # Compute loss
        loss = criterion(predictions, labels)
        
        # Backward pass
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        
        total_loss += loss.item()
        
        if batch_idx % 10 == 0:
            print(f'Epoch {epoch} [{batch_idx}/{len(train_loader)}] Loss: {loss.item():.4f}')
    
    return total_loss / len(train_loader)


def validate(model, val_loader, criterion, device):
    """Validate model."""
    model.eval()
    total_loss = 0
    all_predictions = {k: [] for k in ['diabetes', 'alzheimer', 'cancer', 'cvd']}
    all_labels = {k: [] for k in ['diabetes', 'alzheimer', 'cancer', 'cvd']}
    
    with torch.no_grad():
        for batch, labels in val_loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            labels = {k: v.to(device) for k, v in labels.items()}
            
            predictions = model(batch)
            loss = criterion(predictions, labels)
            total_loss += loss.item()
            
            # Collect predictions
            for disease in all_predictions.keys():
                all_predictions[disease].append(predictions[disease].cpu())
                all_labels[disease].append(labels[disease].cpu())
    
    # Concatenate all batches
    for disease in all_predictions.keys():
        all_predictions[disease] = torch.cat(all_predictions[disease])
        all_labels[disease] = torch.cat(all_labels[disease])
    
    # Compute metrics
    metrics = compute_metrics(all_predictions, all_labels)
    
    return total_loss / len(val_loader), metrics


def main(args):
    # Load configuration
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Setup device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Create datasets
    train_dataset = MultiModalDataset(
        data_dir=config['data']['train_dir'],
        mode='train'
    )
    val_dataset = MultiModalDataset(
        data_dir=config['data']['val_dir'],
        mode='val'
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=True,
        num_workers=config['training']['num_workers']
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=config['training']['batch_size'],
        shuffle=False,
        num_workers=config['training']['num_workers']
    )
    
    # Create model
    model = MultiModalFramework()
    
    # Load pretrained encoders if specified
    if args.pretrained_encoders:
        checkpoint_paths = {
            'diabetes': config['pretrained']['diabetes'],
            'alzheimer': config['pretrained']['alzheimer'],
            'cancer': config['pretrained']['cancer'],
            'cvd': config['pretrained']['cvd']
        }
        model.load_pretrained_encoders(checkpoint_paths)
    
    model = model.to(device)
    
    # Setup training
    criterion = MultiTaskLoss(
        weights=config['loss']['weights'],
        device=device
    )
    
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config['training']['learning_rate'],
        weight_decay=config['training']['weight_decay']
    )
    
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=config['training']['epochs']
    )
    
    # Training loop
    best_val_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(config['training']['epochs']):
        print(f"\nEpoch {epoch+1}/{config['training']['epochs']}")
        
        # Train
        train_loss = train_epoch(model, train_loader, criterion, optimizer, device, epoch)
        
        # Validate
        val_loss, metrics = validate(model, val_loader, criterion, device)
        
        scheduler.step()
        
        print(f"Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
        print("Validation Metrics:")
        for disease, disease_metrics in metrics.items():
            print(f"  {disease}: Acc={disease_metrics['accuracy']:.4f}, "
                  f"F1={disease_metrics['f1']:.4f}")
        
        # Save best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'metrics': metrics
            }, config['training']['checkpoint_dir'] + '/best_model.pth')
            print("Saved best model!")
        else:
            patience_counter += 1
            
        # Early stopping
        if patience_counter >= config['training']['patience']:
            print(f"Early stopping at epoch {epoch+1}")
            break


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True,
                       help='Path to config file')
    parser.add_argument('--pretrained_encoders', action='store_true',
                       help='Use pretrained encoders')
    args = parser.parse_args()
    
    main(args)

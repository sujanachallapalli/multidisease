# Multi-Modal Multi-Disease Deep Learning Framework

Official PyTorch implementation of "Multi-Modal Multi-Disease Deep Learning Framework for Early Detection: Integrating EHR for Diabetes, Brain Imaging for Alzheimer's, Genomics for Cancer, and Wearable Sensors for Cardiovascular Disease"

## Overview

This repository contains the complete implementation of our multi-modal multi-disease detection framework that simultaneously detects:
- **Type 2 Diabetes** from Electronic Health Records (EHR) using BioBERT
- **Alzheimer's Disease** from Brain MRI using 3D ResNet-18
- **Cancer** from Genomic Sequencing using DeepVariant + 1D-CNN
- **Cardiovascular Disease** from ECG signals using WaveNet

## Performance

| Disease | Accuracy | vs. SOTA | Early Detection (6mo) |
|---------|----------|----------|----------------------|
| Diabetes | 89.3% | +7.3% | 78% sensitivity |
| Alzheimer's | 91.7% | +2.5% | 71% sensitivity |
| Cancer | 87.4% | +3.3% | 64% sensitivity |
| CVD | 94.2% | +1.8% | 82% sensitivity |

## Installation

```bash
git clone https://github.com/sujana/multi-disease-multi-modal.git
cd multi-disease-multi-modal
pip install -r requirements.txt
```

## Quick Start

See documentation for detailed usage instructions.

## Citation

```bibtex
@article{multimodal2025,
  title={Multi-Modal Multi-Disease Deep Learning Framework},
  author={Sujana},
  year={2025}
}
```
MIMIC-IV: https://physionet.org/content/mimiciv/ (PhysioNet credentialed
access)
• ADNI: http://adni.loni.usc.edu (application required, free for academics)
• TCGA: https://portal.gdc.cancer.gov (NIH Genomic Data Commons, pub-
lic)
• MIT-BIH/PhysioNet: https://physionet.org/content/mitdb/ (public do-
main)
• Code Repository: https://github.com/[YourUsername]/multi-disease-multi-modal
(PyTorch, full training/inference scripts, preprocessing pipelines)
• Pretrained Models: Available on request for academic research (email authors)
• Propensity Matching Code: R/Python scripts for multi-modal integration pro-
vided in reposito

# GitHub Upload Instructions

Follow these steps to upload the repository to GitHub.

## Prerequisites

1. **GitHub Account**: Ensure you have a GitHub account (https://github.com)
2. **Git Installed**: Install Git on your local machine
   ```bash
   # Check if Git is installed
   git --version
   
   # If not installed (Ubuntu/Debian)
   sudo apt-get install git
   
   # macOS
   brew install git
   ```

3. **GitHub CLI (Optional)**: For easier authentication
   ```bash
   # Install GitHub CLI
   # Ubuntu/Debian
   sudo apt install gh
   
   # macOS
   brew install gh
   ```

## Step-by-Step Upload Process

### Method 1: Using GitHub CLI (Recommended)

```bash
# 1. Navigate to the repository directory
cd /path/to/multi-disease-multi-modal

# 2. Initialize Git repository (if not already)
git init

# 3. Add all files
git add .

# 4. Create initial commit
git commit -m "Initial commit: Multi-Modal Multi-Disease Framework"

# 5. Authenticate with GitHub (first time only)
gh auth login

# 6. Create GitHub repository and push
gh repo create sujana/multi-disease-multi-modal --public --source=. --remote=origin --push

# 7. Set main branch as default
git branch -M main
git push -u origin main
```

### Method 2: Using Git with GitHub Token

```bash
# 1. Navigate to repository
cd /path/to/multi-disease-multi-modal

# 2. Initialize Git
git init

# 3. Add files
git add .

# 4. Commit
git commit -m "Initial commit: Multi-Modal Multi-Disease Framework"

# 5. Go to GitHub and create new repository:
#    - Go to https://github.com/new
#    - Repository name: multi-disease-multi-modal
#    - Description: Multi-Modal Multi-Disease Deep Learning Framework
#    - Select Public
#    - Do NOT initialize with README (we already have one)
#    - Click "Create repository"

# 6. Add remote origin
git remote add origin https://github.com/sujana/multi-disease-multi-modal.git

# 7. Set main branch
git branch -M main

# 8. Push to GitHub
git push -u origin main

# Note: You'll be prompted for GitHub credentials
# Username: sujana
# Password: Use Personal Access Token (not your password)
#   - Create token at: https://github.com/settings/tokens
#   - Select scopes: repo, workflow
```

### Method 3: Using SSH Keys

```bash
# 1. Generate SSH key (if not already)
ssh-keygen -t ed25519 -C "your.email@example.com"

# 2. Add SSH key to ssh-agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# 3. Copy public key
cat ~/.ssh/id_ed25519.pub

# 4. Add to GitHub:
#    - Go to https://github.com/settings/keys
#    - Click "New SSH key"
#    - Paste the key
#    - Click "Add SSH key"

# 5. Initialize and push repository
cd /path/to/multi-disease-multi-modal
git init
git add .
git commit -m "Initial commit: Multi-Modal Multi-Disease Framework"

# 6. Create repo on GitHub (manual or gh CLI)

# 7. Add remote and push
git remote add origin git@github.com:sujana/multi-disease-multi-modal.git
git branch -M main
git push -u origin main
```

## Verify Upload

After pushing, verify at:
https://github.com/sujana/multi-disease-multi-modal

You should see:
- ✓ All files uploaded
- ✓ README.md displayed on main page
- ✓ Directory structure intact
- ✓ All code files present

## Adding Collaborators

```bash
# Using GitHub CLI
gh repo collaborators add username --repo sujana/multi-disease-multi-modal

# Or manually:
# 1. Go to repository settings
# 2. Click "Manage access"
# 3. Click "Invite a collaborator"
# 4. Enter username or email
```

## Creating Releases

```bash
# Tag a version
git tag -a v1.0.0 -m "Initial release"
git push origin v1.0.0

# Create release on GitHub
gh release create v1.0.0 --title "v1.0.0 - Initial Release" --notes "First stable release"
```

## Updating Repository

```bash
# After making changes
git add .
git commit -m "Description of changes"
git push origin main
```

## Common Issues and Solutions

### Issue 1: Authentication Failed
**Solution**: Use Personal Access Token instead of password
- Create at: https://github.com/settings/tokens
- Use token as password when prompted

### Issue 2: Large Files
**Solution**: Use Git LFS for files >100MB
```bash
git lfs install
git lfs track "*.pth"  # Track model files
git add .gitattributes
git commit -m "Add Git LFS"
```

### Issue 3: Permission Denied
**Solution**: Check repository ownership
```bash
# Verify remote URL
git remote -v

# Update if needed
git remote set-url origin https://github.com/sujana/multi-disease-multi-modal.git
```

## .gitignore File

The repository includes a .gitignore file that excludes:
- `__pycache__/`, `*.pyc` - Python cache files
- `data/` - Large datasets
- `checkpoints/` - Model checkpoints
- `.ipynb_checkpoints/` - Jupyter notebook checkpoints
- `*.pth`, `*.pt` - PyTorch model files (upload separately)

## Best Practices

1. **Commit Often**: Make small, logical commits
2. **Write Clear Messages**: Describe what changed and why
3. **Use Branches**: Create feature branches for major changes
4. **Tag Releases**: Use semantic versioning (v1.0.0, v1.1.0, etc.)
5. **Update README**: Keep documentation current
6. **Add Badges**: Include build status, license, etc.

## Repository Badges

Add these to README.md:
```markdown
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.0+](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub stars](https://img.shields.io/github/stars/sujana/multi-disease-multi-modal.svg?style=social)](https://github.com/sujana/multi-disease-multi-modal)
```

## Getting Help

- GitHub Docs: https://docs.github.com
- Git Docs: https://git-scm.com/doc
- GitHub Support: https://support.github.com

## Next Steps After Upload

1. **Enable GitHub Actions**: Set up CI/CD pipelines
2. **Add Documentation**: Create wiki or GitHub Pages
3. **Set Up Issues**: Create issue templates
4. **Add Contributing Guidelines**: Create CONTRIBUTING.md
5. **Community**: Engage with users through issues and discussions
